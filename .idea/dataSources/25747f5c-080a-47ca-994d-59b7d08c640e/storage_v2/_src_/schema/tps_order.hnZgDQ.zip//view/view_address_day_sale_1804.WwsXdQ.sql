create view view_address_day_sale_1804 as (select
                                             `orders`.`address_code`                                       AS `address_code`,
                                             sum(((`goods`.`goods_price` * `goods`.`goods_number`) * 100)) AS `price`,
                                             date_format(`orders`.`pay_time`,
                                                         '%Y-%m-%d')                                       AS `pay_time`,
                                             `goods`.`supplier_id`                                         AS `supplier_id`
                                           from (`tps_order`.`trade_orders_1804` `orders` left join
                                             `tps_order`.`trade_orders_goods_1804` `goods`
                                               on ((`orders`.`order_id` = `goods`.`order_id`)))
                                           where ((`orders`.`is_pure` <> 0) and (`orders`.`order_prop` <> 2) and
                                                  (`orders`.`address_code` is not null) and
                                                  (`orders`.`pay_time` is not null) and (`orders`.`operator` = 1))
                                           group by `goods`.`supplier_id`, `orders`.`address_code`,
                                             date_format(`orders`.`pay_time`, '%Y-%m-%d'));

