create procedure getTotal(IN `$unionSql` varchar(2000))
  begin
      DECLARE cnt INT DEFAULT 0; 
  #set @pg = 500; #SELECT sum(c) FROM ( SELECT count(1) c FROM trade_orders_1710 orders union all SELECT count(1) c FROM trade_orders_1711 orders )temp_a;		
   #select sum(c) into cnt FROM ( SELECT count(1) c FROM trade_orders_1710 orders union all SELECT count(1) c FROM trade_orders_1711 orders )temp_a;		
   #select cnt;

SET @sql = concat('select sum(c) into @cnt FROM ( ', $unionSql,')temp_a');

 PREPARE stmt1 FROM @sql;

 EXECUTE stmt1;

 DEALLOCATE PREPARE stmt1;
select @cnt as total;
                                                       
     end;

