create procedure generate_stat_supplier_assessment_count()
  BEGIN

-- 执行的开始时间和结束时间
DECLARE start_datetime datetime;
DECLARE end_datetime datetime;
-- 循环的当前开始时间和结束时间
DECLARE this_start datetime;
DECLARE this_end datetime;
-- 取表名
DECLARE six_month datetime;
DECLARE `@table_name_one` VARCHAR(5);
DECLARE `@table_name_two` VARCHAR(5);
DECLARE `@sqlstr` VARCHAR(9999);  

SET start_datetime = '2018-03-01 00:00:00';
SET end_datetime = '2018-03-25 00:00:00';
SET six_month = '2017-06-01 00:00:00';

set this_start=start_datetime;
set this_end= date_add(this_start, INTERVAL 1 DAY);
-- 开始循环
WHILE this_start < end_datetime DO
-- 选取表名
IF this_start<six_month THEN 
set `@table_name_one`='';
set `@table_name_two`='_1706';
ELSE 
set `@table_name_one`=CONCAT('_',DATE_FORMAT(this_start,'%y%m'));
set `@table_name_two`=CONCAT('_',DATE_FORMAT(date_add(this_start, INTERVAL 1 MONTH),'%y%m'));
END IF;

-- 删除当前时间范围内数据
delete from stat_supplier_assessment_count WHERE stat_date>=this_start and stat_date<this_end;
-- 查询插入当前时间范围内数据
SET @sqlstr = CONCAT("Insert into stat_supplier_assessment_count(supplier_id,three_order,seven_order,order_count,deliver_date,stat_date,operator)
	SELECT 
		t8.shipper_id AS supplier_id,
    IF ( isnull(three_order),0,three_order ) three_order,
    IF ( isnull(seven_order),0,seven_order ) seven_order,
		order_count,
		deliver_date,
		DATE_FORMAT(pay_time, '%Y-%m-%d') AS stat_date,

	IF (
		isnull(operator),
		0,
		operator
	) operator
	FROM
		(
			SELECT
				shipper_id,
				count(DISTINCT order_id) AS order_count,
pay_time,
				sum(
					TIMESTAMPDIFF(HOUR, pay_time, deliver_time)
				) AS deliver_date
			FROM trade_orders",`@table_name_one`,"
			WHERE
				STATUS IN ('4', '5', '6')
			AND (pay_time >= '",this_start,"' AND pay_time < '",this_end,"')
			AND pay_time < deliver_time
			AND shipper_id = supplier_id
			AND shipper_id > 1000
			GROUP BY
				shipper_id
		) t8
	LEFT JOIN (
		SELECT
			shipper_id,
			count(DISTINCT order_id) AS three_order
		FROM trade_orders",`@table_name_one`,"
		WHERE
			STATUS IN ('4', '5', '6')
		AND (pay_time >= '",this_start,"' AND pay_time < '",this_end,"' )
		AND shipper_id = supplier_id
		AND shipper_id > 1000
		AND (
			DATEDIFF(
				DATE_FORMAT(deliver_time, '%Y-%m-%d'),
				DATE_FORMAT(pay_time, '%Y-%m-%d')
			) <= 4
		)
		GROUP BY
			shipper_id
	) t3 ON t3.shipper_id = t8.shipper_id
	LEFT JOIN (
		SELECT
			shipper_id,
			count(DISTINCT order_id) AS seven_order
		FROM  trade_orders",`@table_name_one`,"
		WHERE
			STATUS IN ('4', '5', '6')
		AND (pay_time >= '",this_start,"' AND pay_time < '",this_end,"')
		AND shipper_id = supplier_id
		AND shipper_id > 1000
		AND (
			DATEDIFF(
				DATE_FORMAT(deliver_time, '%Y-%m-%d'),
				DATE_FORMAT(pay_time, '%Y-%m-%d')
			) <= 8
		)
		GROUP BY
			shipper_id
	) t7 ON t3.shipper_id = t7.shipper_id
	LEFT JOIN (
		SELECT
			shipper_id,
			operator
		FROM  trade_orders",`@table_name_one`,"
		WHERE
			shipper_id = supplier_id
		AND shipper_id > 1000
		AND operator != 0
		GROUP BY
			shipper_id,
			operator
	) t9 ON t3.shipper_id = t9.shipper_id
	UNION ALL
		SELECT
			t3.shipper_id AS supplier_id,
			three_order,
			seven_order,
			order_count,
			deliver_date,
			DATE_FORMAT(pay_time, '%Y-%m-%d') AS stat_date,

		IF (
			isnull(operator),
			0,
			operator
		) operator
		FROM
			(
				SELECT
					shipper_id,
					count(DISTINCT order_id) AS order_count,
					sum(
						TIMESTAMPDIFF(HOUR, pay_time, deliver_time)
					) AS deliver_date
				FROM  trade_orders",`@table_name_two`,"
				WHERE
					STATUS IN ('4', '5', '6')
				AND (pay_time >= '",this_start,"' AND pay_time < '",this_end,"' )
				AND pay_time < deliver_time
				AND shipper_id = supplier_id
				AND shipper_id > 1000
				GROUP BY
					shipper_id
			) t8
		LEFT JOIN (
			SELECT
				shipper_id,
				count(DISTINCT order_id) AS three_order,
				pay_time
			FROM  trade_orders",`@table_name_two`,"
			WHERE
				STATUS IN ('4', '5', '6')
			AND (pay_time >= '",this_start,"' AND pay_time < '",this_end,"' )
			AND shipper_id = supplier_id
			AND shipper_id > 1000
			AND (
				DATEDIFF(
					DATE_FORMAT(deliver_time, '%Y-%m-%d'),
					DATE_FORMAT(pay_time, '%Y-%m-%d')
				) <= 4
			)
			GROUP BY
				shipper_id
		) t3 ON t3.shipper_id = t8.shipper_id
		LEFT JOIN (
			SELECT
				shipper_id,
				count(DISTINCT order_id) AS seven_order
			FROM  trade_orders",`@table_name_two`,"
			WHERE
				STATUS IN ('4', '5', '6')
			AND (pay_time >= '",this_start,"' AND pay_time < '",this_end,"' )
			AND shipper_id = supplier_id
			AND shipper_id > 1000
			AND (
				DATEDIFF(
					DATE_FORMAT(deliver_time, '%Y-%m-%d'),
					DATE_FORMAT(pay_time, '%Y-%m-%d')
				) <= 8
			)
			GROUP BY
				shipper_id
		) t7 ON t3.shipper_id = t7.shipper_id
		LEFT JOIN (
			SELECT
				shipper_id,
				operator
			FROM  trade_orders",`@table_name_two`,"
			WHERE
				shipper_id = supplier_id
			AND shipper_id > 1000
			AND operator != 0
			GROUP BY
				shipper_id,
				operator
		) t9 ON t3.shipper_id = t9.shipper_id");
PREPARE stmt FROM @sqlstr;  
 EXECUTE stmt;   
    -- 当前开始时间设置为当前结束时间，当前结束时间加一天
		set this_start=this_end;
		SET this_end = date_add(this_end, INTERVAL 1 DAY);


END
WHILE;


END;

