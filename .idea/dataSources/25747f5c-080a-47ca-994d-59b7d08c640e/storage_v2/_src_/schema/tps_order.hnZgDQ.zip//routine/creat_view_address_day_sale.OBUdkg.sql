create procedure creat_view_address_day_sale()
  BEGIN
DECLARE `@suffix` VARCHAR(15);  
DECLARE `@sqlstr` VARCHAR(9999);  
SET `@suffix` =  right(DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 1 MONTH),'%Y%m'), 4) ;  
SET @sqlstr = CONCAT(  
"CREATE  OR REPLACE VIEW view_address_day_sale_",  
`@suffix`,  
" AS SELECT orders.address_code,sum(goods.goods_price*goods.goods_number*100) price,DATE_FORMAT(orders.pay_time,'%Y-%m-%d') pay_time,goods.supplier_id from trade_orders_",`@suffix`," orders LEFT JOIN trade_orders_goods_",`@suffix`," goods on orders.order_id=goods.order_id WHERE orders.is_pure!=0 and orders.order_prop!=2 and orders.address_code is not null  and orders.pay_time is not null AND orders.operator=1 GROUP BY goods.supplier_id,orders.address_code,DATE_FORMAT(orders.pay_time,'%Y-%m-%d');"  
);  
PREPARE stmt FROM @sqlstr;  
EXECUTE stmt;  
END;

