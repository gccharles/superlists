create procedure create_table_trade_orders_every_mon()
  BEGIN  
DECLARE `@suffix` VARCHAR(15);  
DECLARE `@sqlstr` VARCHAR(9999);  
SET `@suffix` =  right(DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 1 MONTH),'%Y%m'), 4) ;  
SET @sqlstr = CONCAT(  
"CREATE TABLE IF NOT EXISTS trade_orders_",  
`@suffix`,  
" LIKE trade_orders;"  
);  
PREPARE stmt FROM @sqlstr;  
EXECUTE stmt;  
END;

