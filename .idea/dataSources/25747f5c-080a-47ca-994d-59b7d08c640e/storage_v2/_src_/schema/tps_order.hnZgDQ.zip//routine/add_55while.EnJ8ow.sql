create procedure add_55while()
  BEGIN
    DECLARE i INT DEFAULT 100000;
     WHILE i < 999999 DO
          INSERT INTO trade_orders_1804(order_id,    order_prop,    attach_id,    customer_id,    shopkeeper_id,    AREA,    deliver_time_type,    expect_deliver_date,    goods_list,    need_receipt,    payment_type,    currency,    currency_rate,    discount_type,    goods_amount,    deliver_fee,    order_amount,    goods_amount_usd,    deliver_fee_usd    ,discount_amount_usd,    order_amount_usd,    order_profit_usd,    order_gross_profit_usd,    created_at,    txn_id,    pay_time,    store_code,    deliver_time,    receive_time,    STATUS,    updated_at,    is_export_lock,    is_doba_order,    doba_supplier_id,    supplier_id,    shipper_id,    order_type,    score_year_month,    is_pure,    operator,    logistics_code,    real_deliver_fee,    export_time,    dist_id,    dist_remark_flag,    dist_print_flag,    deliver_status,    export_batch,    dist_express_flag,    dist_yunda_flag,    freight_no,    order_from,    account_type,    address_code,    customs_flag,    doba_order_id,    shop_type,    pure_batch_code    
) VALUES(CONCAT('N201805058760',i),1,'P201801020004052737',1384111625,1384111625,    156,    1,    NULL,    NULL,    0,    0,    'CNY',    6.5,    0,    15160,    0,    15160,    2330,    0,    0,    2330,    855,    0,    '2018-04-27 00:04:09',    0,    '2018-04-27 00:04:09',    0,    '0000-00-00 00:00:00',    '0000-00-00 00:00:00',    99,    '2018-01-17 10:07:10',    0,    0,    0,    2181,    2181,    4,    201801,    2,    0,    -1,    -1,    '0000-00-00 00:00:00',    0,    1,    0,    1,    0,    0,    0,    0,    1,    0,    0,    0,    0,    1,    0);
         SET i = i + 1;
     END WHILE;
 END;

