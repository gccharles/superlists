create procedure add_goods_55while()
  BEGIN
    DECLARE i INT DEFAULT 100000;
     WHILE i < 999999 DO
          INSERT INTO trade_orders_goods_1804(id ,order_id ,goods_sn_main, goods_sn, goods_name, supplier_id, store_code, cate_id ,goods_attr, goods_number, market_price, goods_price, is_doba_goods, price, supply_price, activity_id, goods_type, discount_flag, goods_profit_usd, add_time, hg_flag ,require_id_flag, require_type, activity_name, supply_activity_price
) VALUES(CONCAT('10',i),CONCAT('N201805058760',i), CONCAT(i,'00'), CONCAT(i,'00-1'), '弘康 磁灸护腰腰封（XL）赠送生态磁能量护膝（均码）', 1009, 0, 218, 0, 1, 500, 240, 0, 0, 670, 0, 2, 0, 0, '2016-09-22 16:29:48', 0, 0, 0, 0, 670);
            SET i = i + 1;
     END WHILE;
 END;

