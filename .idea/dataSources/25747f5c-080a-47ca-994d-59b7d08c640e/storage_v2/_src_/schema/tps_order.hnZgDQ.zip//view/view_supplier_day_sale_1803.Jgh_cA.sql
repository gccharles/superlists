create view view_supplier_day_sale_1803 as
  select
    `orders`.`supplier_id`                                        AS `supplier_id`,
    sum(((`goods`.`goods_price` * `goods`.`goods_number`) * 100)) AS `price`,
    date_format(`orders`.`pay_time`, '%Y-%m-%d')                  AS `pay_time`
  from (`tps_order`.`trade_orders_1803` `orders` left join `tps_order`.`trade_orders_goods_1803` `goods`
      on ((`orders`.`order_id` = `goods`.`order_id`)))
  where ((`orders`.`is_pure` <> 0) and (`orders`.`order_prop` <> 2) and (`orders`.`pay_time` is not null))
  group by `orders`.`supplier_id`, date_format(`orders`.`pay_time`, '%Y-%m-%d');

