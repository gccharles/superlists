create procedure create_table_trade_orders_info_every_mon()
  BEGIN  
DECLARE `@suffix` VARCHAR(15);  
DECLARE `@sqlstr` VARCHAR(9999);  
SET `@suffix` =  right(DATE_FORMAT(DATE_ADD(NOW(),INTERVAL 1 MONTH),'%Y%m'), 4) ;  
SET @sqlstr = CONCAT(  
"CREATE TABLE IF NOT EXISTS trade_orders_info_",  
`@suffix`,  
" LIKE trade_orders_info;"  
);  
PREPARE stmt FROM @sqlstr;  
EXECUTE stmt;  
END;

