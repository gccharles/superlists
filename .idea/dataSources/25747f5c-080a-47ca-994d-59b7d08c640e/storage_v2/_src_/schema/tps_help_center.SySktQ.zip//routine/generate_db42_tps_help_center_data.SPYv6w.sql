create procedure generate_db42_tps_help_center_data(IN v_count bigint)
  BEGIN

#控制循环次数
set @vCount=v_count;

#循环初始值
set @vNumber=1;

#时间间隔
set @vinterval=10000;

#html的文章内容格式
set @vsrc='http://tps138.oss-cn-shenzhen.aliyuncs.com/news20170920/dzzc002.png';

#附件地址
set @vattachment ='http://tps-test.tps138.net/idCardScan/20180201/c583bff63a054bb3610f6f9e0e0a3cfb.rar';

while(@vNumber<=@vCount) 
do
	set @vinterval=@vinterval+@vNumber;

	#根据不同语言ID，来插入不同的标题、内容到文章表中
	#language_id：1 英文 2简体中文 3繁体中文 4韩文
	set @vpreLanguageId=floor(1+RAND()*3);
	if @vpreLanguageId=1 then
		set @vTitle='Logistics tracking';
		set @vContent='You can log in to your TPS mall account and view your order''s real-time delivery in my order details page. The logistics information system of some express companies will be slightly delayed. If the order has been shown as the delivery status, but no logistics information will be displayed, please wait for about 24 hours to find out. Or you can directly click on the website of the logistics company to conduct real-time order logistics status inquiry. When you sign for the goods, try to check the goods in person when the delivery person is present (if the Courier insists on the previous check and check the goods, he can check the goods immediately after signing the goods).Please note:1. Be sure to check whether the sealing tape has been disassembled and re-pasted.2. Whether the express package is damaged, leaking or missing.3. If the above situation occurs, we suggest that you contact us as soon as possible, and take photos and archive them, and send the photos to our customer service staff so that we can take the responsibility for the logistics express company.';
		set @vHtmlContent=concat('< img SRC = "',@vsrc,'" _src = "',@vsrc,'" >');
		set @vLanguageId=@vpreLanguageId;

	elseif @vpreLanguageId=2 then
		set @vTitle='这是文章的标题，请不要激动';
		set @vContent='今天天气不冷了，出太阳了。昨天还很冷，是不是，都穿上棉衣了';
		set @vHtmlContent='<p>今天天气不冷了，出太阳了。昨天还很冷，是不是，都穿上棉衣了</p>';
		set @vLanguageId=@vpreLanguageId;
		
	else
		set @vTitle='這是文章的標題，請不要激動';
		set @vContent='今天天氣不冷了，出太陽了。昨天還很冷，是不是，都穿上棉衣了';
		set @vHtmlContent='<p>今天天氣不冷了，出太陽了。昨天還很冷，是不是，都穿上棉衣了</p>';
		set @vLanguageId=@vpreLanguageId;
	end if;

	#获取文章类别ID
	select id into @vcateId from `article_cate`  where `status`=1 and `type`=1 and `language_id`=@vLanguageId order by rand() limit 1;
			
	#获取文章主键最大值
	select ifnull(max(id)+1,1) into @varticleId from article;
	
	#hot: 1热门 0非热门 language_id：1 英文 2简体中文 3繁体中文 4韩文 is_show：1显示 0不显示 status 状态： -1删除 0回收 1草稿 2正式 
	#show_front_index：位置的展示 0前端不展示 1前端首页 like_count：点赞记录数量 hate_count：踩记录数量 smart_lamp：醒目灯 1开启 0关闭
	#topper：置顶 1开启 0关闭 prohibited_reproduced：禁止转载 1开启 0关闭
	INSERT INTO `article` (`id`,`title`, `content`, `html_content`, `cover`, `author`, `source`,
							`sort`, `hot`, `language_id`, `cate_id`, `is_show`, `status`, `show_front_index`, 
							`create_admin_id`, `create_admin_name`, `update_admin_id`, `update_admin_name`, `create_time`, `update_time`, `like_count`, 
							`hate_count`, `attachment`, `smart_lamp`, `topper`, `prohibited_reproduced`, `old_status`) 
	VALUES (@varticleId,@vTitle, @vContent, @vHtmlContent, NULL, NULL, NULL, 
	floor(1+RAND()*10000000), floor(0+RAND()*2), @vLanguageId, @vcateId, floor(0+RAND()*2), floor(0+RAND()*4)-1, floor(0+RAND()*2),
	3, 'tpsManager01', NULL, NULL, DATE_FORMAT(LOCALTIME()+@vinterval,'%Y-%m-%d %H:%i:%S'), DATE_FORMAT(LOCALTIME()+@vinterval+30000,'%Y-%m-%d %H:%i:%S'), floor(10000+RAND()*1000000), 
	floor(10+RAND()*1000), @vattachment, floor(0+RAND()*2),floor(0+RAND()*2), floor(0+RAND()*2), NULL);
	
	set @vNumber=@vNumber+1;
	
	END WHILE;
end;

