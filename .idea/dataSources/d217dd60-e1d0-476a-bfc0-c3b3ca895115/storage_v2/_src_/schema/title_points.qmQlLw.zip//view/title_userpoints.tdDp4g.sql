create view title_userpoints as select
                                  `title_points`.`title_points_138`.`userId`      AS `userId`,
                                  `title_points`.`title_points_138`.`title_grade` AS `titleGrade`,
                                  `title_points`.`title_points_138`.`title_name`  AS `titleName`
                                from `title_points`.`title_points_138`
                                union select
                                        `title_points`.`title_points_139`.`userId`      AS `userId`,
                                        `title_points`.`title_points_139`.`title_grade` AS `title_grade`,
                                        `title_points`.`title_points_139`.`title_name`  AS `title_name`
                                      from `title_points`.`title_points_139`;

