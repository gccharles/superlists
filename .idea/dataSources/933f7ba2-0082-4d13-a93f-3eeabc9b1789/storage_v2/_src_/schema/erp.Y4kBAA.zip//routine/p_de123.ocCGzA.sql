create procedure P_DE123()
  BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < 10 DO
        INSERT INTO DE123(id,supplier_id,sale_amount)  VALUES(i,'9068','20180426');
         SET i = i + 1;
    END WHILE;
END;

