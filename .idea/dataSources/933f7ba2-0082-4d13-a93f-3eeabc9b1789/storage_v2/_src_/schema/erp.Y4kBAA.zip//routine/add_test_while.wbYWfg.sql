create procedure add_test_while()
  BEGIN
    DECLARE i INT DEFAULT 1110;
     WHILE i < 9999 DO
          INSERT INTO test_while(id,PSN,SN) VALUES(CONCAT('N',i),03,52);
         SET i = i + 1;
     END WHILE;
 END;

