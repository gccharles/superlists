create procedure add_0426()
  BEGIN
    DECLARE i INT DEFAULT 2018010240654478103;
     WHILE i < 2018010240684478103 DO
          INSERT INTO erp_stat_commodity_sale_count(id,goods_sn_main,language_id,operator_id,supplier_id,shipper_id,sale_count,sale_amount,order_count,STATUS,stat_date)VALUES(i,00416387,2,1,2635,2635,1,1016,1,'3','2018-04-25');
         SET i = i + 1;
     END WHILE;
 END;

