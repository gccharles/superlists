create definer = tps138test@`%` event test_event_0426
  on schedule
    every '1' DAY
      starts '2018-04-26 17:55:00'
  enable
do
  CALL P_DE123();

