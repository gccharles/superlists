create procedure repair_month_fee_one()
  BEGIN 
             DECLARE _month_fee_pool,_monthFee,_old_month_fee_pool  DECIMAL(14,2) DEFAULT 0; 
             DECLARE _user_id ,_data_id,minct ,maxct,Done ,t_error,_type,_del_id,record_count,_cur_type INTEGER DEFAULT 0;   
             
             --  创建临时表 	  
             CREATE  TEMPORARY TABLE IF NOT EXISTS  tmp_repair_month_fee_change_table(
		`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,  
                `uid` INT  UNSIGNED  NOT NULL, 
                `data_id` INT UNSIGNED NOT NULL,
                PRIMARY KEY (`id`)  
	     )ENGINE=MYISAM DEFAULT CHARSET=utf8;    
	     SET @STMT ='INSERT INTO tmp_repair_month_fee_change_table (`uid`,`data_id`)SELECT user_id,`id` FROM month_fee_change WHERE month_fee_pool<0    AND create_time>"2017-2-10 01:00:00"   ;';
	     PREPARE STMT FROM @STMT;
	      EXECUTE STMT; 
             SELECT MIN(a.`id`),MAX(a.`id`) INTO minct ,maxct FROM  tmp_repair_month_fee_change_table a; -- 获取表最小id 最大id   
                  IF maxct-minct>=0&&minct>0 THEN    
			 SET t_error=0;
			  START TRANSACTION;
			WHILE minct <= maxct DO    			      
			        SET _data_id=0; SET _user_id=0; SET _del_id=0; SET _cur_type=0; SET _type=0;
			 	SELECT uid,data_id INTO _user_id,_data_id FROM tmp_repair_month_fee_change_table WHERE    id=minct;    
		         IF _data_id<>0  THEN 
		           -- 查询当前月费池
                          SELECT   	month_fee_pool ,`type` INTO  _month_fee_pool,_cur_type  FROM 	 month_fee_change WHERE id= _data_id;    
		         -- 查找最近是否涉及到转月费操作  
			   SELECT  `type`,`id`  INTO _type,_del_id FROM ( SELECT `type`,id FROM month_fee_change WHERE user_id=_user_id    ORDER BY id DESC  LIMIT 2 ) A ORDER  BY id ASC LIMIT 1;
			  IF  (_type=4 OR _type=8 )AND _month_fee_pool<0 THEN 
			    -- 删除当前记录
                             DELETE FROM month_fee_change WHERE id=_data_id;
                             SELECT COUNT(uid)INTO record_count FROM   users_month_fee_fail_info  WHERE uid =_user_id;
                             IF record_count=0 THEN 
                                    INSERT INTO users_month_fee_fail_info(uid) VALUES(_user_id);
                             END IF;   
                           END IF;	 
		      END IF;
		     SET minct = minct + 1;   
		  END WHILE;
		  IF t_error = 1 THEN   
				ROLLBACK;   
			ELSE  
				COMMIT;       
			END IF;
		  END IF; 
		 
             
    END;

