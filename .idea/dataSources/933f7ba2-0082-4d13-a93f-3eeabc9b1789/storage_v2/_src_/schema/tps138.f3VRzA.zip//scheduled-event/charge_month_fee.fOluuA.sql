create definer = tps138@`%` event charge_month_fee
  on schedule
    every '1' DAY
      starts '2017-02-21 00:45:01'
  on completion preserve
  disable on slave
  comment '扣月费'
do
  call charge_month_fee(0,0);

