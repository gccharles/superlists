create view ly_view as
  select
    `tps138`.`users`.`parent_id` AS `parent_id`,
    count(0)                     AS `num`
  from `tps138`.`users`
  where (`tps138`.`users`.`user_rank` <> 4)
  group by `tps138`.`users`.`parent_id`
  having (`num` > 25)
  order by `num` desc
  limit 20;

