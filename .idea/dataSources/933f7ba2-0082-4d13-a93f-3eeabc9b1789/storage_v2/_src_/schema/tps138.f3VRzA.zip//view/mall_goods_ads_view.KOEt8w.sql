create view mall_goods_ads_view as
  select
    `a`.`id`                        AS `id`,
    `a`.`position_id`               AS `position_id`,
    `a`.`media`                     AS `media`,
    `a`.`flow_code`                 AS `flow_code`,
    `a`.`ad_img`                    AS `ad_img`,
    `a`.`status`                    AS `status`,
    `a`.`img_subhead`               AS `img_subhead`,
    `a`.`action_type`               AS `action_type`,
    `a`.`region_code`               AS `region_code`,
    `a`.`action_val`                AS `action_val`,
    `a`.`is_default`                AS `is_default`,
    ifnull(`s`.`sort_order`, 99999) AS `sort_order`,
    ifnull(`s`.`status`, 0)         AS `sort_status`,
    ifnull(`t`.`start_date`, 0)     AS `start_date`,
    ifnull(`t`.`end_date`, 0)       AS `end_date`
  from ((`tps138`.`mall_goods_ads` `a` left join `tps138`.`mall_goods_ads_sort` `s`
      on (((`a`.`sort_id` = `s`.`id`) and (`s`.`status` = 1)))) left join `tps138`.`mall_goods_ads_time` `t`
      on (((`a`.`time_id` = `t`.`id`) and (`t`.`start_date` <= curdate()) and (`t`.`end_date` >= curdate()))))
  where (`a`.`status` = 1)
  order by ifnull(`s`.`sort_order`, 99999);

