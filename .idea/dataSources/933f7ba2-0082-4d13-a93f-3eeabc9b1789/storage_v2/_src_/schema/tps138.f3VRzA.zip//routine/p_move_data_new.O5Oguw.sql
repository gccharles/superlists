create procedure P_MOVE_DATA_NEW(IN in_01 bigint, OUT out_01 varchar(99))
  BEGIN
    DECLARE maxt  BIGINT DEFAULT 0;
    DECLARE max01 BIGINT DEFAULT 0;
    DECLARE max02 BIGINT DEFAULT 0;
    DECLARE _var,_err INT DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION, SQLWARNING, NOT FOUND SET _err=1;
    SELECT MAX(id) INTO maxt FROM trade_orders_1709;
    SELECT MAX(max_id) INTO max02 FROM t_log_record;
--    insert into t_payrecord_copy select * from t_payrecord where id > max02 and id <= maxt;
    SET max02 = IFNULL(max02,0);
     SELECT max02;
     SELECT maxt;
    WHILE (maxt >= in_01 + max02) DO
  INSERT INTO ak_title_order_ack_1709(id,userId,orderNo,amount,orderType,orderstate,sendFlag,orderTime) 
        SELECT
        id,
  customer_id userId,
  order_id orderNo,
  order_amount amount,
  order_type orderType,
   1,
  'N',
  DATE_FORMAT(created_at, '%Y%m%d%H%i%S') orderTime
FROM
  trade_orders_1709
WHERE (
       order_type = '1'
    OR order_type = '2'
    OR order_type = '4'
    OR order_type = '5'
  )
  AND (
    STATUS = '1'
    OR STATUS = '3'
    OR STATUS = '4'
    OR STATUS = '5'
    OR STATUS = '6'
    OR STATUS = '90'
    OR STATUS = '97'
    )
  AND        
    id > max02 AND id <= max02 + in_01;
       SET max02 = max02 + in_01;
    -- select max02; 
    END WHILE;
    
    IF maxt >= max02 THEN
  INSERT INTO ak_title_order_ack_1709(id,userId,orderNo,amount,orderType,orderstate,sendFlag,orderTime) 
        SELECT
        id,
  customer_id userId,
  order_id orderNo,
  order_amount amount,
  order_type orderType,
  1,
  'N',
  DATE_FORMAT(created_at, '%Y%m%d%H%i%S') orderTime
FROM
  trade_orders_1709 
WHERE (
    order_type = '1'
    OR order_type = '2'
    OR order_type = '4'
    OR order_type = '5'
  )
  AND (
    STATUS = '1'
    OR STATUS = '3'
    OR STATUS = '4'
    OR STATUS = '5'
    OR STATUS = '6'
    OR STATUS = '90'
    OR STATUS = '97'
    )
  AND        
   id > max02 AND id <= maxt;
    END IF;
    IF _err=1 THEN
        SET _var = 2;
    END IF;
    SELECT MAX(id) INTO max01 FROM ak_title_order_ack_1709;
    SELECT max01;
    SELECT _var;
   ### 错误记录
    IF _var = 2 THEN
    
    INSERT INTO t_log_record(max_id,time_st,errlog)VALUEs(max01,NOW(),'cuowu');
    SET out_01='chucuo';
    else 
    INSERT INTO t_log_record(max_id,time_st,errlog)VALUES(max01,NOW(),'succ');
    END IF;
    SELECT out_01;
END;

