create definer = tps138@`%` event pro_store_statistics_totals
  on schedule
    every '1' DAY
      starts '2017-01-22 00:00:03'
  on completion preserve
  disable on slave
  comment '每天凌晨统计昨天的会员加盟情况。'
do
  call pro_store_statistics_totals();

