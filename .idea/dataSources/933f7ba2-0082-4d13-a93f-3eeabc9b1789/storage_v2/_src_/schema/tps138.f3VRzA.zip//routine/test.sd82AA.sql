create procedure test()
  BEGIN 
DECLARE `@sqlupdate` VARCHAR(9999);  
DECLARE `@sqladd` VARCHAR(9999);  
DECLARE `@sqldelete` VARCHAR(9999);  
DECLARE u_id int(10);  
DECLARE cnt int(10);  
DECLARE amount_usd varchar(255);  
DECLARE done INT DEFAULT FALSE; 
DECLARE _Cur CURSOR FOR (select customer_id, order_amount_usd from temp_score );  
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 绑定控制变量到游标,游标循环结束自动转true 

OPEN _Cur;   
     read_loop: LOOP  
            FETCH _Cur INTO u_id, amount_usd;    

            IF done THEN -- 判断是否继续循环  
LEAVE read_loop; -- 结束循环  
END IF;  

SET @sqladd = CONCAT("update users_store_sale_info_monthly set sale_amount=sale_amount+",amount_usd," where `year_month` ='201803' and uid=",u_id);  
 insert into test VALUES (@sqladd);
PREPARE stmt FROM @sqladd;  
 EXECUTE stmt;  
-- 更新条数不等于1，记录下来
 set cnt = row_count();
IF cnt!=1 THEN -- 判断是否继续循环  
set @sqlupdate=CONCAT("update temp_score set flag=0 where customer_id=",u_id);
insert into test VALUES (@sqlupdate);
PREPARE stmt FROM @sqlupdate;  
  EXECUTE stmt; 
else 
 SET @sqldelete = CONCAT("update users_store_sale_info_monthly set sale_amount=sale_amount-",amount_usd," where `year_month` ='201804' and uid=",u_id);  
insert into test VALUES (@sqldelete);	
 PREPARE stmt FROM @sqldelete;  
 EXECUTE stmt; 
END IF;  
commit;
     END LOOP;  
CLOSE _Cur;    



END;

