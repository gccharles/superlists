create procedure ly_debug(IN de_content text)
  BEGIN
################调试用的存储过程######################

insert into debug_logs(content) values(de_content);

END;

