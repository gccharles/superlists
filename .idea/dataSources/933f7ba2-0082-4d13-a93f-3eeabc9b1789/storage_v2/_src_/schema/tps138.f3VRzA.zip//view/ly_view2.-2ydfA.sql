create view ly_view2 as
  select
    `b`.`id`                                   AS `会员id`,
    `b`.`name`                                 AS `会员姓名`,
    if((`b`.`sale_rank` = 5), '销售副总裁', '市场总监') AS `会员职称`,
    `b`.`address`                              AS `地址`,
    `a`.`num`                                  AS `直推的付费会员数量`
  from (`tps138`.`ly_view` `a` left join `tps138`.`users` `b` on ((`a`.`parent_id` = `b`.`id`)))
  where (`b`.`sale_rank` > 3)
  limit 15;

