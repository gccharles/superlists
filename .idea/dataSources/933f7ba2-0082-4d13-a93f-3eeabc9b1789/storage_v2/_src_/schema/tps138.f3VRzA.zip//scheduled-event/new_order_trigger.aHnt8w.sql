create definer = tps138@`%` event new_order_trigger
  on schedule
    every '10' SECOND
      starts '2017-02-15 17:10:00'
  on completion preserve
  disable on slave
  comment '执行订单关联动作。'
do
  call new_order_trigger();

