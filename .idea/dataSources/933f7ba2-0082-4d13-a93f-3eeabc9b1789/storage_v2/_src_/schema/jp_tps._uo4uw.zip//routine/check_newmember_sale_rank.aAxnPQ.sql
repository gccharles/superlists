create procedure check_newmember_sale_rank(IN p_uid int(10))
  BEGIN




DECLARE g_vp_num int(10);
DECLARE g_sd_num int(10);
DECLARE g_sm_num int(10);
DECLARE g_mso_num int(10);
DECLARE g_payed_child_num int(10);


select count(*) into g_vp_num from users_child_group_info where uid=p_uid and vp_num>0;
if g_vp_num>2 THEN

	update users set sale_rank=5,sale_rank_up_time=now() where id=p_uid;
ELSE

	select count(*) into g_sd_num from users_child_group_info where uid=p_uid and sd_num>0;
	if g_sd_num>2 THEN

		update users set sale_rank=4,sale_rank_up_time=now() where id=p_uid;
	ELSE
		
		select count(*) into g_sm_num from users_child_group_info where uid=p_uid and sm_num>0;
		if g_sm_num>2 THEN

			update users set sale_rank=3,sale_rank_up_time=now() where id=p_uid;
		ELSE

			select count(*) into g_mso_num from users_child_group_info where uid=p_uid and mso_num>0;
			if g_mso_num>2 THEN
				
				update users set sale_rank=2,sale_rank_up_time=now() where id=p_uid;
			ELSE
				
				select count(*) into g_payed_child_num from users where parent_id=p_uid and user_rank<>4;
				if g_payed_child_num>2 THEN

					update users set sale_rank=1,sale_rank_up_time=now() where id=p_uid;
				end if;
			end if;
		end if;
	end if;
end if;

END;

