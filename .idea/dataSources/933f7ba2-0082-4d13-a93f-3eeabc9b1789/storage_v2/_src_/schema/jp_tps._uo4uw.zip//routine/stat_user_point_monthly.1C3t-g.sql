create procedure stat_user_point_monthly()
  BEGIN



DECLARE t_error int default 0;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
set autocommit=0;


TRUNCATE table users_profit_sharing_point_last_month;


insert into users_profit_sharing_point_last_month(uid,profit_sharing_point) select id,round(profit_sharing_point*100) 
from users where profit_sharing_point!=0;


IF t_error = 1 THEN
	ROLLBACK;insert into logs_cron(content) values('[Fail] 每月初统计用户分红点.');
ELSE
	COMMIT;insert into logs_cron(content) values('[Success] 每月初统计用户分红点.');
END IF;
SET autocommit=1;

END;

