create procedure add_to_daily_elite_qualified_list(IN qualified_uid int)
  BEGIN


DECLARE u_pro_set_amount int default 0;
DECLARE u_sale_amount int DEFAULT 0;
DECLARE exit_qualified_day int DEFAULT -1;


DECLARE t_error int default 0;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
set autocommit=0;


select pro_set_amount into u_pro_set_amount FROM stat_intr_mem_month where uid=qualified_uid 
and `year_month`=DATE_FORMAT(now(),'%Y%m');


select sale_amount into u_sale_amount from users_store_sale_info_monthly where uid=qualified_uid 
and `year_month`=DATE_FORMAT(now(),'%Y%m');


select qualified_day into exit_qualified_day from daily_bonus_elite_qualified_list where uid=qualified_uid;
if exit_qualified_day=-1 THEN
	
	insert into daily_bonus_elite_qualified_list(uid,bonus_shar_weight,qualified_day) 
values(qualified_uid,u_pro_set_amount+u_sale_amount,DATE_FORMAT(now(),'%Y%m%d'));
elseif exit_qualified_day=DATE_FORMAT(now(),'%Y%m%d') THEN
	
	replace into daily_bonus_elite_qualified_list(uid,bonus_shar_weight,qualified_day) 
values(qualified_uid,u_pro_set_amount+u_sale_amount,DATE_FORMAT(now(),'%Y%m%d'));
end if;


IF t_error = 1 THEN
	ROLLBACK;insert into error_log(content) values(concat('加入精英日分红合格列表失败，uid:',qualified_uid));
ELSE
	COMMIT;
END IF;
SET autocommit=1;

END;

