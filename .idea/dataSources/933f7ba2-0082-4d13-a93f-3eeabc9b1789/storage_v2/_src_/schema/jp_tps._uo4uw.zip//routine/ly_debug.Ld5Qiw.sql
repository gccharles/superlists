create procedure ly_debug(IN de_content text)
  BEGIN


insert into debug_logs(content) values(de_content);

END;

