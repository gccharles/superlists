create procedure month_begin()
  BEGIN


call stat_user_point_monthly();
call new_cash_log_tb();

END;

