create procedure new_order_trigger()
  BEGIN
DECLARE now_time VARCHAR (20) ;
DECLARE end_time VARCHAR (20) DEFAULT '2017-04-01 00:00:00';
DECLARE team_profit_end_time VARCHAR (20) DEFAULT '2017-03-01 00:00:00';
DECLARE t_run_cycle_num smallint(5) default -1;
DECLARE order_ids_del text;
DECLARE f_oid VARCHAR(40);
DECLARE f_uid int(10);
DECLARE f_order_amount_usd int(10);
DECLARE f_order_profit_usd int(10);
DECLARE f_order_year_month mediumint(6);
DECLARE u_status TINYINT(1) default 1;
DECLARE u_monthfee_pool decimal(14,2) default 0.00;
DECLARE u_store_qualified TINYINT(1);
DECLARE u_user_rank TINYINT(3);
DECLARE u_sale_rank TINYINT(3);
DECLARE cur_sale_amount int;
DECLARE total_sale_amount int(10);
DECLARE comm_store_owner int;
DECLARE cur_year_month MEDIUMINT(6) default DATE_FORMAT(now(),'%Y%m');
DECLARE cur_cash_tb_name varchar(30) default concat('cash_account_log_',DATE_FORMAT(now(),'%Y%m'));
DECLARE u_proportion decimal(5,2);
DECLARE comm_to_point int;
DECLARE u_parent_ids longtext;
DECLARE i int(10);
DECLARE done_parent_ids int(1);
DECLARE p_id varchar(10);
DECLARE p_user_rank,p_store_qualified tinyint(1);
DECLARE comm_parent int;
DECLARE p_qualified_child_num int;
DECLARE p_enable_floor_num TINYINT(2);
DECLARE u_reward_id int(10);
DECLARE u_amount_profit_sharing_comm decimal(14,2);
DECLARE h_daily_bonus_elite int;
DECLARE h_138_bonus int;
DECLARE h_week_bonus int;
DECLARE u_x int;
DECLARE u_y int;
DECLARE group_floor_num TINYINT DEFAULT 3;

DECLARE t_error INT DEFAULT 0;
DECLARE done int default 0;
DECLARE cur_queue CURSOR FOR SELECT oid,uid,order_amount_usd,order_profit_usd,order_year_month 
FROM new_order_trigger_queue where create_time<SUBDATE(now(),interval 180 second) LIMIT 500;
DECLARE CONTINUE HANDLER FOR NOT FOUND set done=1;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;


select run_cycle_num into t_run_cycle_num from single_task_control where task_name='new_order_trigger';
if t_run_cycle_num=-1 THEN

	
	insert into single_task_control(task_name) values('new_order_trigger');

	
	SET now_time = UNIX_TIMESTAMP(NOW()) ;
	set end_time = UNIX_TIMESTAMP(end_time);
	set team_profit_end_time = UNIX_TIMESTAMP(team_profit_end_time);
	
	if now_time > end_time THEN
	  SET group_floor_num = 2;
	ELSE
	  SET  group_floor_num = 3;
  end if;

	set done=0;
	set autocommit=0;
	OPEN cur_queue;
	FETCH cur_queue INTO f_oid,f_uid,f_order_amount_usd,f_order_profit_usd,f_order_year_month;

	WHILE done<>1 do
		
		insert into users_store_sale_info(uid,sale_amount) values(f_uid,f_order_amount_usd) on DUPLICATE KEY 
	UPDATE sale_amount=sale_amount+f_order_amount_usd;
		
		
		SELECT order_year_month into f_order_year_month from withdraw_task where uid=f_uid and `status`=1 limit 1;
		if done=1 then
			set done=0;
		else
			delete from withdraw_task where uid=f_uid and `status`=1 and sale_amount_lack<=f_order_amount_usd;
			update withdraw_task set sale_amount_lack=sale_amount_lack-f_order_amount_usd where uid=f_uid and `status`=1;

			
			case substring(f_oid,1,2)
				when 'W-' THEN
					update mall_orders set score_year_month=f_order_year_month where order_id=f_oid;
				when 'O-' THEN
					update one_direct_orders set score_year_month=f_order_year_month where order_id=f_oid;
				when 'A-' THEN
					update walmart_orders set score_year_month=f_order_year_month where order_id=f_oid;
				else
					update trade_orders set score_year_month=f_order_year_month where order_id=f_oid;
			end case;
			
		end if;
		
		insert into users_store_sale_info_monthly(uid,`year_month`,sale_amount) values(f_uid,f_order_year_month,
	f_order_amount_usd) on DUPLICATE KEY UPDATE sale_amount=sale_amount+f_order_amount_usd;
		call user_rank_change_week_comm(f_uid,0,0,2);

		
		set cur_sale_amount=0;
		SELECT sale_amount into cur_sale_amount from users_store_sale_info_monthly where uid=f_uid and `year_month`=
	cur_year_month;
		if done=1 then set done=0;end if;

		
		set total_sale_amount=0;
		SELECT sale_amount into total_sale_amount from users_store_sale_info where uid=f_uid;
		if done=1 then set done=0;end if;

		
		select user_rank,sale_rank,`status`,month_fee_pool,left(parent_ids,109),store_qualified,amount_profit_sharing_comm
	into u_user_rank,u_sale_rank,u_status,u_monthfee_pool,u_parent_ids,u_store_qualified,u_amount_profit_sharing_comm
	from users where id=f_uid;

		
		if u_status=2 THEN
			select id from users_april_plan where uid=f_uid and `type`=1;
			if done=1 then
				set done=0;
			else
				
				insert into users_april_plan_order(uid,order_id) values(f_uid,f_oid);
				insert into trade_order_remark_record(order_id,`type`,remark,admin_id) values(f_oid,1,'System: The retail orders
	for "the Initiatives to waive past due monthly fee(s)" can\'t be cancelled or returned',0);
				insert into trade_order_remark_record(order_id,`type`,remark,admin_id) values(f_oid,2,'System: The retail orders
	for "the Initiatives to waive past due monthly fee(s)" can\'t be cancelled or returned',0);
				if cur_sale_amount>=5000 then 
					
					update users set `status`=1,store_qualified=1 where id=f_uid;
					delete from users_month_fee_fail_info where uid=f_uid;
					insert into users_status_log(uid,front_status,back_status,`type`,create_time)
	values(f_uid,2,1,2,unix_timestamp());
					insert into month_fee_change(user_id,old_month_fee_pool,month_fee_pool,cash,create_time,`type`) values(f_uid,
	u_monthfee_pool,u_monthfee_pool,0.00,now(),8);
					delete from users_april_plan where uid=f_uid;
				end if;
			end if;
		end if;

		
		set comm_store_owner =ROUND(f_order_profit_usd*0.2);
		if comm_store_owner>0 then

			
			set @STMT :=concat('insert into ',cur_cash_tb_name,'(uid,item_type,amount,order_id)
	values(',f_uid,',5,',comm_store_owner,",'",f_oid,"')");
			PREPARE STMT FROM @STMT;
			EXECUTE STMT;

			
			set comm_to_point=0;
			set u_proportion=0.00;
			select proportion/100 into u_proportion from profit_sharing_point_proportion where uid=f_uid and proportion_type=1;
			if u_proportion>0.00 THEN

				
				set comm_to_point = ROUND(comm_store_owner * u_proportion);
				if comm_to_point>0 then

					
					update users set profit_sharing_point=profit_sharing_point+comm_to_point/100,
	profit_sharing_point_from_sale=profit_sharing_point_from_sale+comm_to_point/100 where id=f_uid;

					
					set @STMT :=concat('insert into ',cur_cash_tb_name,'(uid,item_type,amount)
	values(',f_uid,',17,',-1*comm_to_point,')');
					PREPARE STMT FROM @STMT;
					EXECUTE STMT;

					
					insert into profit_sharing_point_add_log(uid,add_source,money,point,create_time) values(f_uid,1,
	comm_to_point/100,comm_to_point/100,unix_timestamp());
				end if;
			else
				set done=0;
			end if;

			
			update users set amount=amount+(comm_store_owner-comm_to_point)/100,amount_store_commission=
	amount_store_commission+comm_store_owner/100 where id=f_uid;
		end if;

		
		set i=0;set done_parent_ids=0;
		WHILE (i<group_floor_num and done_parent_ids=0) do
			set p_id = substring(u_parent_ids,i*11+1,10);
			if (p_id<>'1380100217' and p_id!='') then
				select user_rank,store_qualified into p_user_rank,p_store_qualified from users where id=p_id;
				if done=0 THEN

					set comm_parent=0;

					  
            
            
            
            
            

            IF now_time <= team_profit_end_time THEN
              if i=0 THEN

              
              if p_user_rank=1 then set comm_parent=round(f_order_profit_usd*0.2);
              elseif p_user_rank=2 then set comm_parent=round(f_order_profit_usd*0.15);
              elseif p_user_rank=3 then set comm_parent=round(f_order_profit_usd*0.1);
              elseif p_user_rank=5 then set comm_parent=round(f_order_profit_usd*0.07);
              else set comm_parent=round(f_order_profit_usd*0.05);
              end if;
            ELSE

              if p_store_qualified=1 then

                
                select count(*) into p_qualified_child_num from users where parent_id=p_id and user_rank<>4
      and store_qualified=1;
                case p_user_rank
                  when 1 then
                    if p_qualified_child_num>=3 then set p_enable_floor_num=10;
                    elseif p_qualified_child_num=2 then set p_enable_floor_num=6;
                    elseif p_qualified_child_num=1 then set p_enable_floor_num=3;
                    else set p_enable_floor_num=1;end if;
                  when 2 THEN
                    if p_qualified_child_num>=2 then set p_enable_floor_num=6;
                    elseif p_qualified_child_num=1 then set p_enable_floor_num=3;
                    else set p_enable_floor_num=1;end if;
                  when 3 THEN
                    if p_qualified_child_num>=1 then set p_enable_floor_num=3;
                    else set p_enable_floor_num=1;end if;
                  when 5 THEN
                    if p_qualified_child_num>=1 then set p_enable_floor_num=2;
                    else set p_enable_floor_num=1;end if;
                  else set p_enable_floor_num=1;
                end case;
                if p_enable_floor_num>=i+1 then

                  
                  case p_user_rank
                    when 1 THEN
                      if i=1 then set comm_parent=round(f_order_profit_usd*0.1);
                      elseif i=2 then set comm_parent=round(f_order_profit_usd*0.05);
                      else set comm_parent=round(f_order_profit_usd*0.02);end if;
                    when 2 THEN
                      if i=1 then set comm_parent=round(f_order_profit_usd*0.08);
                      elseif i=2 then set comm_parent=round(f_order_profit_usd*0.05);
                      else set comm_parent=round(f_order_profit_usd*0.02);end if;
                    when 3 THEN
                      if i=1 then set comm_parent=round(f_order_profit_usd*0.05);
                      else set comm_parent=round(f_order_profit_usd*0.03);end if;
                    else set comm_parent=round(f_order_profit_usd*0.05);
                  end case;
                end if;
              end if;
            end if;
            ELSE 
              if i=0 THEN
                if p_user_rank=1 then set comm_parent=round(f_order_profit_usd*0.2);
                elseif p_user_rank=2 then set comm_parent=round(f_order_profit_usd*0.15);
                elseif p_user_rank=3 then set comm_parent=round(f_order_profit_usd*0.12);
                elseif p_user_rank=5 then set comm_parent=round(f_order_profit_usd*0.1);
                else set comm_parent=round(f_order_profit_usd*0.05);
                end if;
              ELSE
                if p_user_rank=1 then set comm_parent=round(f_order_profit_usd*0.12);
                elseif p_user_rank=2 then set comm_parent=round(f_order_profit_usd*0.10);
                elseif p_user_rank=3 then set comm_parent=round(f_order_profit_usd*0.07);
                elseif p_user_rank=5 then set comm_parent=round(f_order_profit_usd*0.05);
                else set comm_parent=round(f_order_profit_usd*0.05);
                end if;
              END IF;
              
              if i = 1 THEN

                set  done_parent_ids = 1;
              end if;
            END IF;

					
					if comm_parent>0 then

						
						set @STMT :=concat('insert into ',cur_cash_tb_name,'(uid,item_type,amount,order_id,related_uid)
				values(',p_id,',3,',comm_parent,",'",f_oid,"','",f_uid,"')");
						PREPARE STMT FROM @STMT;
						EXECUTE STMT;

						
						set comm_to_point=0;
						set u_proportion=0.00;
						select proportion/100 into u_proportion from profit_sharing_point_proportion where uid=p_id and
	proportion_type=1;
						if u_proportion>0.00 THEN

							
							set comm_to_point = ROUND(comm_parent * u_proportion);
							if comm_to_point>0 then

								
								update users set profit_sharing_point=profit_sharing_point+comm_to_point/100,
				profit_sharing_point_from_sale=profit_sharing_point_from_sale+comm_to_point/100 where id=p_id;

								
								set @STMT :=concat('insert into ',cur_cash_tb_name,'(uid,item_type,amount)
				values(',p_id,',17,',-1*comm_to_point,')');
								PREPARE STMT FROM @STMT;
								EXECUTE STMT;

								
								insert into profit_sharing_point_add_log(uid,add_source,money,point,create_time) values(p_id,1,
				comm_to_point/100,comm_to_point/100,unix_timestamp());
							end if;
						else
							set done=0;
						end if;

						
						update users set amount=amount+(comm_parent-comm_to_point)/100,team_commission=
				team_commission+comm_parent/100 where id=p_id;
					end if;
				ELSE
					set done=0;
				end if;
			ELSE
				set done_parent_ids=1;
			end if;
			set i=i+1;
		END WHILE;

		
		if u_user_rank=4 and total_sale_amount>=5000 THEN
			if u_store_qualified=0 THEN
				update users set store_qualified=1 where id=f_uid;
			end if;
			if total_sale_amount>=10000 THEN
				select id into u_reward_id from users_sharing_point_reward where uid=f_uid limit 1;
				if done=1 then
					set done=0;
					insert into users_sharing_point_reward(uid,point,end_time) values(f_uid,100,
	DATE_ADD(DATE_FORMAT(now(),'%Y-%m-%d'),INTERVAL 15 MONTH));
				end if;
			end if;
		end if;

		
		


    if now_time < end_time THEN

        if u_amount_profit_sharing_comm=0 and total_sale_amount>=2500 then
          if u_user_rank<>4 or total_sale_amount>=10000 THEN

            INSERT IGNORE INTO daily_bonus_qualified_list(uid,qualified_day) VALUES (f_uid,DATE_FORMAT(now(),'%Y%m%d'));
          end if;
        end if;
    end if;
    
		
		set h_daily_bonus_elite=0;
		set h_138_bonus=0;
		set h_week_bonus=0;
		SELECT daily_bonus_elite,138_bonus,week_bonus into h_daily_bonus_elite,h_138_bonus,h_week_bonus from user_comm_stat
	where uid=f_uid;
		if done=1 then set done=0;end if;

		
		
		if now_time < end_time THEN
      if cur_sale_amount>=25000 and h_daily_bonus_elite=0 THEN
        call add_to_daily_elite_qualified_list(f_uid);
      end if;
    end if;
    
		
		if now_time < end_time THEN

      if h_138_bonus=0 and cur_sale_amount>=5000 and u_user_rank in(1,2,3,5) THEN
        set u_x=0;set u_y=0;
        select x,y into u_x,u_y from user_coordinates where user_id=f_uid;
        if done=1 then set done=0;end if;
        if u_x>0 and u_y>0 THEN
          insert IGNORE into user_qualified_for_138(user_id,user_rank,sale_amount,x,y) values(f_uid,u_user_rank,cur_sale_amount,u_x,u_y);
        end if;
      end if;
    end if;
		
		if(order_ids_del is null) then
			set order_ids_del=concat('\'',f_oid,'\'');
		else
			set order_ids_del = concat(order_ids_del,',','\'',f_oid,'\'');
		end if;

		FETCH cur_queue INTO f_oid,f_uid,f_order_amount_usd,f_order_profit_usd,f_order_year_month;
	END WHILE;
	CLOSE cur_queue;

	
	if order_ids_del is not null then
		set @STMT :=concat('delete from new_order_trigger_queue where oid in(',order_ids_del,')');
		PREPARE STMT FROM @STMT;
		EXECUTE STMT;
	end if;

	
	IF t_error = 1 THEN
		ROLLBACK;
	ELSE
		COMMIT;
	END IF;
	SET autocommit=1;
	

	
	delete from single_task_control where task_name='new_order_trigger';

ELSE

	
	if t_run_cycle_num<30 then
		update single_task_control set run_cycle_num=run_cycle_num+1 where task_name='new_order_trigger';
	ELSE
		delete from single_task_control where task_name='new_order_trigger';
	end if;
end if;

END;

