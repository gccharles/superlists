create procedure nextSeqValue(IN seqName varchar(128), IN size int unsigned, IN maxVal bigint unsigned,
                              IN cycle   tinyint unsigned, OUT newVal bigint unsigned)
  BEGIN
    DECLARE mysqlError  INT     DEFAULT 0;
    DECLARE mySqlState  INT     DEFAULT 0;
    DECLARE errorMsg    TEXT    DEFAULT 'N/A';

    DECLARE hasError    TINYINT DEFAULT 0;
    DECLARE rowsChanged TINYINT DEFAULT 0;
    DECLARE retry       TINYINT DEFAULT 1;

    DECLARE out_of_range CONDITION FOR 1690;
    DECLARE CONTINUE HANDLER FOR out_of_range
    BEGIN
        SET mysqlError = 1690;
        SET mySqlState = 22003;
        SET errorMsg   = 'Out of range: Attempting to update a value that exceeds maximum value allowed.';

        SET hasError = 1;
        IF cycle = 0 THEN
            SET retry = 0;
        END IF;
    END;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        SET mysqlError = -1;
        SET mySqlState = -1;
        SET errorMsg   = 'Hit some error when executing SQL statement.';

        SET hasError = 1;
        SET retry = 0;
    END;

    IF size <= 0 THEN
        SET size = 1;
    END IF;

    START TRANSACTION;

    UPDATE sequence_opt
    SET value = LAST_INSERT_ID(value + increment_by * (size - 1)) + increment_by, gmt_modified = NOW()
    WHERE name = seqName;

    error_handler: LOOP

        IF hasError = 0 THEN
            SELECT ROW_COUNT() INTO rowsChanged;

            IF rowsChanged = 0 THEN
                SET mysqlError = 0;
                SET mySqlState = 0;
                SET errorMsg   = concat('Not Changed: Sequence ', seqName, ' was not initialized or updated for some reason.');
                SET newval = 0;
                ROLLBACK;
                LEAVE error_handler;
            ELSE
                SELECT LAST_INSERT_ID() INTO newVal;

                IF newVal > maxVal THEN
                    IF cycle = 0 OR retry = 0 THEN
                        SET hasError   = 1;
                        SET mysqlError = 1690;
                        SET mySqlState = 22003;
                        SET errorMsg   = concat('Out of Range: Attempting to generate sequence value ', newVal, ' that exceeds the maximum value ', maxVal, ' allowed.');
                        SET newVal     = 0;
                        ROLLBACK;
                        LEAVE error_handler;
                    END IF;
                ELSE
                    COMMIT;
                    LEAVE error_handler;
                END IF;
            END IF;
        ELSE
            IF retry = 0 THEN
                SET newval = 0;
                ROLLBACK;
                LEAVE error_handler;
            ELSE
                SET hasError   = 0;
                SET mysqlError = 0;
                SET mySqlState = 0;
                SET errorMsg   = 'N/A';
            END IF;
        END IF;

        IF retry = 1 THEN
            UPDATE sequence_opt
            SET value = LAST_INSERT_ID(start_with + increment_by * (size - 1)) + increment_by, gmt_modified = NOW()
            WHERE name = seqName;

            SET retry = 0;

            ITERATE error_handler;
        END IF;

    END LOOP error_handler;

    SELECT mysqlError as 'MySQL Error', mySqlState as 'SQLSTATE', errorMsg as 'Error Message';
END;

