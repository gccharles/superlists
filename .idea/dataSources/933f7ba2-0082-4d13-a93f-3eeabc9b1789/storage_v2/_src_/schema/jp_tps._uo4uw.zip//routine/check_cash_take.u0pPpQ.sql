create procedure check_cash_take()
  BEGIN

DECLARE Done INT DEFAULT 0;

DECLARE CurrentUid INT(10);
	   
declare CancleNum INT(10);
	   
declare Type12Num INT(10);

declare errNum INT(10);


DECLARE rs CURSOR FOR SELECT COUNT(*) as num,uid from cash_take_out_logs where `status`=4 and `create_time` >='2017-08-01 00:00:00' and `create_time`< '2017-10-01 00:00:00' GROUP BY uid;


DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET Done = 1;


OPEN rs;

FETCH NEXT FROM rs INTO CancleNum, CurrentUid; 

REPEAT
  IF NOT Done THEN
  SELECT   (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1380
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1381
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1382
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1383
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1384
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1385
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1386
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1387
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1388
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) into Type12Num;
			
  set errNum = Type12Num - CancleNum;
  
  IF errNum  > 0 THEN 
   INSERT INTO cash_take_cancle_err_log(`uid`,`Num`)VALUES(CurrentUid,errNum);
set errNum=0;
set Type12Num=0;
set CancleNum=0;
	END IF;
 END IF;

FETCH NEXT FROM rs INTO CancleNum, CurrentUid; 
 
UNTIL Done END REPEAT;


CLOSE rs;
END;

