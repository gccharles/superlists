create procedure new_week_share_list()
  BEGIN



DECLARE t_error INT DEFAULT 0;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
set autocommit=0;


truncate week_share_qualified_list;

insert ignore into week_share_qualified_list(uid,sale_amount_weight,sale_rank_weight,store_rank_weight,share_point_weight
) select a.uid,a.sale_amount,b.sale_rank*b.sale_rank,if(b.user_rank=3,1,if(b.user_rank=1,3,2)),round(b.profit_sharing_point*100) from users_store_sale_info_monthly a left join users b 
on a.uid=b.id where a.`year_month`=DATE_FORMAT(date_add(curdate(),interval -1 month),'%Y%m') and b.user_rank in(3,2,1) 
and b.sale_rank in(1,2,3,4,5) and a.sale_amount>=7500;


IF t_error = 1 THEN
	ROLLBACK;insert into error_log(content) values('每月初生成新的周团队分红发奖列表失败.');
ELSE
	COMMIT;insert into logs_cron(content) values('[Success] 每月初生成新的周团队分红发奖列表.');
END IF;
SET autocommit=1;

END;

