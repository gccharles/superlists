create procedure grant_week_share(IN istest tinyint(1))
  BEGIN


DECLARE t_error INT DEFAULT 0;
DECLARE totalProfit_wh BIGINT DEFAULT 0;
DECLARE totalProfit_tps BIGINT DEFAULT 0;
DECLARE totalProfit_1di BIGINT DEFAULT 0;
DECLARE totalProfit BIGINT DEFAULT 0;
DECLARE tp_sale_amount_weight BIGINT DEFAULT 0;
DECLARE tp_sale_rank_weight BIGINT DEFAULT 0;
DECLARE tp_store_rank_weight BIGINT DEFAULT 0;
DECLARE tp_share_point_weight BIGINT DEFAULT 0;
DECLARE tn_sale_amount_weight BIGINT DEFAULT 0;
DECLARE tn_sale_rank_weight BIGINT DEFAULT 0;
DECLARE tn_store_rank_weight BIGINT DEFAULT 0;
DECLARE tn_share_point_weight BIGINT DEFAULT 0;
DECLARE comm_amount int DEFAULT 0;
DECLARE n_week_time varchar(30);
DECLARE s_week_time varchar(30);
DECLARE li_uid int;
DECLARE li_sale_amount_weight int;
DECLARE li_sale_rank_weight tinyint;
DECLARE li_store_rank_weight tinyint;
DECLARE li_share_point_weight int;
DECLARE done int default 0;
DECLARE cur_list CURSOR FOR select uid,sale_amount_weight,sale_rank_weight,store_rank_weight,share_point_weight from
week_share_qualified_list WHERE create_time < CURDATE();
DECLARE CONTINUE HANDLER FOR NOT FOUND set done=1;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;


set n_week_time = subdate(curdate(),date_format(curdate(),'%w')-1); 
set s_week_time = subdate(date_add( n_week_time, interval -2 day) ,date_format( date_add(n_week_time, interval -2 day),'%w' )-1); 


select round(if(sum(order_profit_usd) is not null,sum(order_profit_usd),0)*100) into totalProfit_wh from mall_orders 
where create_time>=s_week_time and create_time<n_week_time;

select round(if(sum(order_profit_usd) is not null,sum(order_profit_usd),0)*100) into totalProfit_1di from 
one_direct_orders where create_time>=s_week_time and create_time<n_week_time;

select if(sum(order_profit_usd) is not null,sum(order_profit_usd),0) into totalProfit_tps from trade_orders 
where pay_time>=s_week_time and pay_time<n_week_time and order_prop in('0','2') and `status` in('3','4','5','6');


set totalProfit = round((totalProfit_wh+totalProfit_1di+totalProfit_tps)*0.19191);
set tp_sale_amount_weight = round(totalProfit*0.1);
set tp_sale_rank_weight = round(totalProfit*0.78);
set tp_store_rank_weight = round(totalProfit*0.1);
set tp_share_point_weight = round(totalProfit*0.02);


select sum(sale_amount_weight) into tn_sale_amount_weight from week_share_qualified_list;
select sum(sale_rank_weight) into tn_sale_rank_weight from week_share_qualified_list;
select sum(store_rank_weight) into tn_store_rank_weight from week_share_qualified_list;
select sum(share_point_weight) into tn_share_point_weight from week_share_qualified_list;

set autocommit=0;
set done=0;
OPEN cur_list;
FETCH cur_list INTO li_uid,li_sale_amount_weight,li_sale_rank_weight,li_store_rank_weight,li_share_point_weight;
WHILE done=0 do

	select id into li_uid from users where id=li_uid and store_qualified=1;
	if done=0 THEN
		set comm_amount = round(tp_sale_amount_weight/tn_sale_amount_weight*li_sale_amount_weight + 
tp_sale_rank_weight/tn_sale_rank_weight*li_sale_rank_weight + 
tp_store_rank_weight/tn_store_rank_weight*li_store_rank_weight +
tp_share_point_weight/tn_share_point_weight*li_share_point_weight);
		if istest=1 THEN
			call ly_debug(concat(li_uid,':',comm_amount/100));
		ELSE
			call grant_comm_single(li_uid,comm_amount,25,'');
		end if;
	ELSE
		set done=0;
	end if;

	FETCH cur_list INTO li_uid,li_sale_amount_weight,li_sale_rank_weight,li_store_rank_weight,li_share_point_weight;
END WHILE;
CLOSE cur_list;



IF t_error = 1 THEN
 	ROLLBACK;insert into error_log(content) values('发放周团队销售分红失败.');
ELSE
 	COMMIT;insert into logs_cron(content) values('[Success] 发放周团队销售分红.');
END IF;
SET autocommit=1;

END;

