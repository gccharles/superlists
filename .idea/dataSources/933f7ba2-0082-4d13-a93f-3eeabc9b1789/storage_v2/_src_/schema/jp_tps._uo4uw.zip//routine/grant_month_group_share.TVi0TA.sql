create procedure grant_month_group_share(IN istest tinyint(1))
  BEGIN



DECLARE totalProfit_wh BIGINT DEFAULT 0;
DECLARE totalProfit_tps BIGINT DEFAULT 0;
DECLARE totalProfit_1di BIGINT DEFAULT 0;
DECLARE totalProfit BIGINT DEFAULT 0;
DECLARE tp_sale_amount_weight BIGINT DEFAULT 0;
DECLARE tp_sale_rank_weight BIGINT DEFAULT 0;
DECLARE tp_store_rank_weight BIGINT DEFAULT 0;
DECLARE tn_sale_amount_weight BIGINT DEFAULT 0;
DECLARE tn_sale_rank_weight BIGINT DEFAULT 0;
DECLARE tn_store_rank_weight BIGINT DEFAULT 0;
DECLARE comm_amount int DEFAULT 0;
DECLARE li_uid int;
DECLARE li_sale_amount_weight int;
DECLARE li_sale_rank_weight int;
DECLARE li_store_rank_weight tinyint;

DECLARE t_error INT DEFAULT 0;
DECLARE done int default 0;
DECLARE cur_list CURSOR FOR select uid,sale_amount_weight,sale_rank_weight,store_rank_weight from
 month_group_share_list;
DECLARE CONTINUE HANDLER FOR NOT FOUND set done=1;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;


select round(if(sum(order_profit_usd) is not null,sum(order_profit_usd),0)*100) into totalProfit_wh from mall_orders 
where create_time>='2017-02-01' and create_time<'2017-03-01';
select round(if(sum(order_profit_usd) is not null,sum(order_profit_usd),0)*100) into totalProfit_1di from 
one_direct_orders where create_time>='2017-02-01' and create_time<'2017-03-01';
select if(sum(order_profit_usd) is not null,sum(order_profit_usd),0) into totalProfit_tps from trade_orders 
where pay_time>='2017-02-01' and pay_time<'2017-03-01' and order_prop in('0','2') and `status` in('3','4','5','6');
set totalProfit = round((totalProfit_wh+totalProfit_1di+totalProfit_tps)*0.24709);
set tp_sale_amount_weight = round(totalProfit*0.1);
set tp_sale_rank_weight = round(totalProfit*0.8);
set tp_store_rank_weight = round(totalProfit*0.1);


select sum(sale_amount_weight) into tn_sale_amount_weight from month_group_share_list;
select sum(sale_rank_weight) into tn_sale_rank_weight from month_group_share_list;
select sum(store_rank_weight) into tn_store_rank_weight from month_group_share_list;

set autocommit=0;
set done=0;
OPEN cur_list;
FETCH cur_list INTO li_uid,li_sale_amount_weight,li_sale_rank_weight,li_store_rank_weight;
WHILE done=0 do

	select id into li_uid from users where id=li_uid and store_qualified=1;
	if done=0 THEN
		set comm_amount = round(tp_sale_amount_weight/tn_sale_amount_weight*li_sale_amount_weight + 
tp_sale_rank_weight/tn_sale_rank_weight*li_sale_rank_weight + 
tp_store_rank_weight/tn_store_rank_weight*li_store_rank_weight);
		if istest=1 THEN
			call ly_debug(concat(li_uid,':',comm_amount/100));
		ELSE
			call grant_comm_single(li_uid,comm_amount,1,'');
		end if;
	ELSE
		set done=0;
	end if;

	FETCH cur_list INTO li_uid,li_sale_amount_weight,li_sale_rank_weight,li_store_rank_weight;
END WHILE;
CLOSE cur_list;



IF t_error = 1 THEN
 	ROLLBACK;insert into error_log(content) values('发放月团队组织分红失败.');
ELSE
 	COMMIT;insert into logs_cron(content) values('[Success] 发放月团队组织分红.');
END IF;
SET autocommit=1;

END;

