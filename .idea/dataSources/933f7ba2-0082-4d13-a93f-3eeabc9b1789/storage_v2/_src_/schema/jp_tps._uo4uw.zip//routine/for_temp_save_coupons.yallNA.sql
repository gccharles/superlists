create procedure for_temp_save_coupons(IN p_uid int(10), IN p_oid char(19))
  BEGIN


DECLARE li_coupons_value int(11);
DECLARE li_coupons_num int(11);
DECLARE i int;

DECLARE done int default 0;
DECLARE cur_list CURSOR FOR select coupons_value,coupons_num from temp_save_coupons where order_id=p_oid and user_id=
p_uid;
DECLARE CONTINUE HANDLER FOR NOT FOUND set done=1;


OPEN cur_list;
FETCH cur_list INTO li_coupons_value,li_coupons_num;
WHILE done=0 do

	set i=0;
	while (i<li_coupons_num) do

		insert into user_suite_exchange_coupon(face_value,uid) values(li_coupons_value,p_uid);
		set i=i+1;
	end WHILE;

	FETCH cur_list INTO li_coupons_value,li_coupons_num;
END WHILE;
CLOSE cur_list;



delete from temp_save_coupons where user_id=p_uid and order_id=p_oid;

END;

