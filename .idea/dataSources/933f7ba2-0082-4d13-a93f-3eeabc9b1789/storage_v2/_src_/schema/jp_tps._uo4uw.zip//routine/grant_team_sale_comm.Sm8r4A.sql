create procedure grant_team_sale_comm(IN p_uid            int(10), IN p_oid char(19), IN p_order_profit int,
                                      IN grant_parent_ids char(32))
  BEGIN





DECLARE cur_cash_tb_name varchar(30) default concat('cash_account_log_',DATE_FORMAT(now(),'%Y%m'));
DECLARE i int(10);
DECLARE u_proportion decimal(5,2);
DECLARE comm_to_point int;
DECLARE done_parent_ids int(1);
DECLARE p_id varchar(10);
DECLARE p_user_rank,p_store_qualified tinyint(1);
DECLARE comm_parent int default 0;
DECLARE p_qualified_child_num int;
DECLARE p_enable_floor_num TINYINT(2);


set i=0;set done_parent_ids=0;
WHILE (i<3 and done_parent_ids=0) do
	set p_id = substring(grant_parent_ids,i*11+1,10);
	if (p_id<>'1380100217' and p_id!='') then
		select user_rank,store_qualified into p_user_rank,p_store_qualified from users where id=p_id;
		if p_user_rank is not null THEN

			set comm_parent=0;
			if i=0 THEN

				
				if p_user_rank=1 then set comm_parent=round(p_order_profit*0.2);
				elseif p_user_rank=2 then set comm_parent=round(p_order_profit*0.15);
				elseif p_user_rank=3 then set comm_parent=round(p_order_profit*0.1);
				elseif p_user_rank=5 then set comm_parent=round(p_order_profit*0.07);
				else set comm_parent=round(p_order_profit*0.05);
				end if;
			ELSE
				
				if p_store_qualified=1 then

					
					select count(*) into p_qualified_child_num from users where parent_id=p_id and user_rank<>4 
and store_qualified=1;
					case p_user_rank
						when 1 then
							if p_qualified_child_num>=3 then set p_enable_floor_num=10;
							elseif p_qualified_child_num=2 then set p_enable_floor_num=6;
							elseif p_qualified_child_num=1 then set p_enable_floor_num=3;
							else set p_enable_floor_num=1;end if;
						when 2 THEN
							if p_qualified_child_num>=2 then set p_enable_floor_num=6;
							elseif p_qualified_child_num=1 then set p_enable_floor_num=3;
							else set p_enable_floor_num=1;end if;
						when 3 THEN
							if p_qualified_child_num>=1 then set p_enable_floor_num=3;
							else set p_enable_floor_num=1;end if;
						when 5 THEN
							if p_qualified_child_num>=1 then set p_enable_floor_num=2;
							else set p_enable_floor_num=1;end if;
						else set p_enable_floor_num=1;
					end case;
					if p_enable_floor_num>=i+1 then
						
						
						case p_user_rank
							when 1 THEN
								if i=1 then set comm_parent=round(p_order_profit*0.1);
								elseif i=2 then set comm_parent=round(p_order_profit*0.05);
								else set comm_parent=round(p_order_profit*0.02);end if;
							when 2 THEN
								if i=1 then set comm_parent=round(p_order_profit*0.08);
								elseif i=2 then set comm_parent=round(p_order_profit*0.05);
								else set comm_parent=round(p_order_profit*0.02);end if;
							when 3 THEN
								if i=1 then set comm_parent=round(p_order_profit*0.05);
								else set comm_parent=round(p_order_profit*0.03);end if;
							else set comm_parent=round(p_order_profit*0.05);
						end case;	
					end if;
				end if;
			end if;

			
			if comm_parent>0 then

				
				set @STMT :=concat('insert into ',cur_cash_tb_name,'(uid,item_type,amount,order_id,related_uid) 
		values(',p_id,',3,',comm_parent,",'",p_oid,"','",p_uid,"')");
				PREPARE STMT FROM @STMT;
				EXECUTE STMT;

				
				set comm_to_point=0;
				set u_proportion=0.00;
				select proportion/100 into u_proportion from profit_sharing_point_proportion where uid=p_id and 
proportion_type=1;
				if u_proportion>0.00 THEN

					
					set comm_to_point = ROUND(comm_parent * u_proportion);
					if comm_to_point>0 then

						
						update users set profit_sharing_point=profit_sharing_point+comm_to_point/100,
		profit_sharing_point_from_sale=profit_sharing_point_from_sale+comm_to_point/100 where id=p_id;

						
						set @STMT :=concat('insert into ',cur_cash_tb_name,'(uid,item_type,amount) 
		values(',p_id,',17,',-1*comm_to_point,')');
						PREPARE STMT FROM @STMT;
						EXECUTE STMT;

						
						insert into profit_sharing_point_add_log(uid,add_source,money,point,create_time) values(p_id,1,
		comm_to_point/100,comm_to_point/100,unix_timestamp());
					end if;
				end if;
				
				
				update users set amount=amount+(comm_parent-comm_to_point)/100,team_commission=
		team_commission+comm_parent/100 where id=p_id;
			end if;
		end if;
	ELSE
		set done_parent_ids=1;
	end if;
	set i=i+1;
END WHILE;

END;

