create procedure `138_shar_prepare2`(OUT totalNum int, OUT totalSharNum int)
  BEGIN


select count(*) into totalNum from user_qualified_for_138;
select x,y into @lastX,@lastY from user_coordinates order by id desc limit 1;
insert into 138_grant_tmp2(uid,num_share) select user_id,(@lastY-y)-if(x>@lastX,1,0) from user_qualified_for_138;
select sum(num_share) into totalSharNum from 138_grant_tmp2;

END;

