create procedure repair_month_fee()
  BEGIN 
             DECLARE _month_fee_pool,_monthFee,_old_month_fee_pool  DECIMAL(14,2) DEFAULT 0; 
             DECLARE _user_id ,_data_id,minct ,maxct,Done ,t_error,record_count INTEGER DEFAULT 0; 
             
             
             CREATE  TEMPORARY TABLE IF NOT EXISTS  tmp_repair_month_fee_change_table(
		`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,  
                `uid` INT  UNSIGNED  NOT NULL, 
                `data_id` INT UNSIGNED NOT NULL,
                PRIMARY KEY (`id`)  
	     )ENGINE=MYISAM DEFAULT CHARSET=utf8;    
	     
	     SET @STMT ='INSERT INTO tmp_repair_month_fee_change_table (`uid`,`data_id`)SELECT user_id,`id` FROM month_fee_change WHERE month_fee_pool<0    AND create_time>"2017-2-10 01:00:00" ;';
	     PREPARE STMT FROM @STMT;
	     EXECUTE STMT; 
             SELECT MIN(a.`id`),MAX(a.`id`) INTO minct ,maxct FROM  tmp_repair_month_fee_change_table a; 
                  IF maxct-minct>=0&&minct>0 THEN   
			WHILE minct <= maxct DO     
			        SET _data_id=0; SET _user_id=0;  SET _old_month_fee_pool=0; SET _month_fee_pool=0;
				SELECT uid,data_id INTO _user_id,_data_id FROM tmp_repair_month_fee_change_table WHERE    id=minct;   
		             IF _data_id<>0  THEN  
				
				SELECT  A.month_fee_pool INTO _old_month_fee_pool FROM 
				( SELECT   month_fee_pool,id FROM month_fee_change WHERE user_id=_user_id AND create_time<'2017-02-10 02:30:01' AND 
				create_time>'2017-02-10 02:14:59' ORDER BY id DESC  LIMIT 2 ) A  ORDER  BY A.id ASC LIMIT 1;		
				IF _old_month_fee_pool>0 THEN 				
					SET t_error=0;
					START TRANSACTION;
					
					UPDATE month_fee_change SET `old_month_fee_pool`=_old_month_fee_pool WHERE id=_data_id ;
					UPDATE month_fee_change SET `month_fee_pool`=`old_month_fee_pool`+`cash` WHERE user_id=_user_id   AND id=_data_id;
					SELECT month_fee_pool INTO _month_fee_pool  FROM  month_fee_change  WHERE   user_id=_user_id AND  ID=_data_id ;					 			 
					UPDATE users SET `month_fee_pool`=_month_fee_pool WHERE id=_user_id ; 
					IF t_error = 1 THEN   
						ROLLBACK;   
					ELSE   
						COMMIT;       
					END IF; 
				END IF; 
			END IF;
			SET minct = minct + 1;   
			END WHILE;   
		  END IF;  
    END;

