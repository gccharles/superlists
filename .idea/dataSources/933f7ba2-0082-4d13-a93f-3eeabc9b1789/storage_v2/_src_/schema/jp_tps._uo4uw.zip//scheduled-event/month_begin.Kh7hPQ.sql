create definer = tps138@`%` event month_begin
  on schedule
    every '1' MONTH
      starts '2016-10-01 00:03:01'
  on completion preserve
  disable on slave
  comment '每月初执行统计任务'
do
  call month_begin();

