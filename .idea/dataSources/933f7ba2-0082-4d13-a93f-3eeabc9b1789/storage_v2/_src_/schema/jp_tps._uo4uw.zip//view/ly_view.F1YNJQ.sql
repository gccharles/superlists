create view ly_view as
  select
    `jp_tps`.`users`.`parent_id` AS `parent_id`,
    count(0)                     AS `num`
  from `jp_tps`.`users`
  where (`jp_tps`.`users`.`user_rank` <> 4)
  group by `jp_tps`.`users`.`parent_id`
  having (`num` > 25)
  order by `num` desc
  limit 20;

