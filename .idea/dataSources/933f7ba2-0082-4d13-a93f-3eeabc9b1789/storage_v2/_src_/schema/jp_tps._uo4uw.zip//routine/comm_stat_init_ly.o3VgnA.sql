create procedure comm_stat_init_ly()
  BEGIN

DECLARE f_id int;
DECLARE comm int;
DECLARE comm_7 int;
DECLARE comm_8 int;
DECLARE comm_9 int;
DECLARE comm_total int;

DECLARE done int default 0;
DECLARE cur_queue CURSOR FOR SELECT id FROM users order by id LIMIT 180000,20000;
DECLARE CONTINUE HANDLER FOR NOT FOUND set done=1;
OPEN cur_queue;
FETCH cur_queue INTO f_id;
WHILE done<>1 do

	
	set comm=0;set comm_7=0;set comm_8=0;set comm_9=0;set comm_total=0;
	select round(sum(amount)*100) into comm from commission_logs where uid=f_id and `type`=24;
	select sum(amount) into comm_7 from cash_account_log_201607 where uid=f_id and item_type=24;
	select sum(amount) into comm_8 from cash_account_log_201608 where uid=f_id and item_type=24;
	select sum(amount) into comm_9 from cash_account_log_201609 where uid=f_id and item_type=24;
	if comm is not null THEN
		set comm_total=comm_total+comm;
	end if;
	if comm_7 is not null THEN
		set comm_total=comm_total+comm_7;
	end if;
	if comm_8 is not null THEN
		set comm_total=comm_total+comm_8;
	end if;
	if comm_9 is not null THEN
		set comm_total=comm_total+comm_9;
	end if;
	insert into user_comm_stat(uid,daily_bonus_elite) values(f_id,comm_total) on DUPLICATE KEY 
UPDATE daily_bonus_elite=daily_bonus_elite+comm_total;

	
	set comm=0;set comm_7=0;set comm_8=0;set comm_9=0;set comm_total=0;
	select round(sum(amount)*100) into comm from commission_logs where uid=f_id and `type`=2;
	select sum(amount) into comm_7 from cash_account_log_201607 where uid=f_id and item_type=2;
	select sum(amount) into comm_8 from cash_account_log_201608 where uid=f_id and item_type=2;
	select sum(amount) into comm_9 from cash_account_log_201609 where uid=f_id and item_type=2;
	if comm is not null THEN
		set comm_total=comm_total+comm;
	end if;
	if comm_7 is not null THEN
		set comm_total=comm_total+comm_7;
	end if;
	if comm_8 is not null THEN
		set comm_total=comm_total+comm_8;
	end if;
	if comm_9 is not null THEN
		set comm_total=comm_total+comm_9;
	end if;
	insert into user_comm_stat(uid,138_bonus) values(f_id,comm_total) on DUPLICATE KEY 
UPDATE 138_bonus=138_bonus+comm_total;

	
	set comm=0;set comm_7=0;set comm_8=0;set comm_9=0;set comm_total=0;
	select round(sum(amount)*100) into comm from commission_logs where uid=f_id and `type`=7;
	select sum(amount) into comm_7 from cash_account_log_201607 where uid=f_id and item_type=7;
	select sum(amount) into comm_8 from cash_account_log_201608 where uid=f_id and item_type=7;
	select sum(amount) into comm_9 from cash_account_log_201609 where uid=f_id and item_type=7;
	if comm is not null THEN
		set comm_total=comm_total+comm;
	end if;
	if comm_7 is not null THEN
		set comm_total=comm_total+comm_7;
	end if;
	if comm_8 is not null THEN
		set comm_total=comm_total+comm_8;
	end if;
	if comm_9 is not null THEN
		set comm_total=comm_total+comm_9;
	end if;
	insert into user_comm_stat(uid,week_bonus) values(f_id,comm_total) on DUPLICATE KEY 
UPDATE week_bonus=week_bonus+comm_total;

	set done=0;


FETCH cur_queue INTO f_id;
END WHILE;
CLOSE cur_queue;

END;

