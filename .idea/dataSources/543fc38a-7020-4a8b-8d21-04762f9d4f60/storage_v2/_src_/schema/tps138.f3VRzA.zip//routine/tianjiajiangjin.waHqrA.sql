create procedure tianjiajiangjin(IN uid int, IN item_type tinyint, IN amount int)
  BEGIN
SET @id = 0;
SET @uid = uid;
SET @item_type = item_type;
SET @amount =amount;

select ifnull(max(id)+1,1) into @id from cash_account_log_201710_1380;

INSERT INTO cash_account_log_201710_1380(id,uid,item_type,amount,create_time)
VALUES(@id,@uid,@item_type,@amount,STR_TO_DATE('" + alarmDefi.getEndTime()+ "','%Y-%m-%d %k:%i:%s'));

COMMIT;
END;

