create procedure add_trade_orders_1711(IN order_id   char(19), IN customer_id int, IN area char(3),
                                       IN order_from tinyint, IN attach_id char(19), IN score_year_month char(6))
  BEGIN
SET @id = 0;
SET @order_id = order_id;
SET @customer_id = customer_id;
SET @area = area;
SET @order_from = order_from;
SET @updated_at = STR_TO_DATE('" + alarmDefi.getEndTime()+ "','%Y-%m-%d %k:%i:%s');
SET @attach_id =attach_id;
SET @score_year_month = score_year_month;
SELECT IFNULL(MAX(id)+1,1) INTO @id FROM trade_orders_1711;

INSERT INTO trade_orders_1711(id,order_id,customer_id,area,order_from,updated_at,attach_id,score_year_month)
VALUES(@id,@order_id,@customer_id,@area,@order_from,@updated_at,@attach_id,@score_year_month);
COMMIT;
END;

