create view cash_log_sum as select (sum(`tps138`.`commission_logs`.`amount`) * 100) AS `sum_amount`
                            from `tps138`.`commission_logs`
                            where (`tps138`.`commission_logs`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201607`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201607`
                                  where (`tps138`.`cash_account_log_201607`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201608`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201608`
                                  where (`tps138`.`cash_account_log_201608`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201609`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201609`
                                  where (`tps138`.`cash_account_log_201609`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201610`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201610`
                                  where (`tps138`.`cash_account_log_201610`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201611`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201611`
                                  where (`tps138`.`cash_account_log_201611`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201612`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201612`
                                  where (`tps138`.`cash_account_log_201612`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201701`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201701`
                                  where (`tps138`.`cash_account_log_201701`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201702`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201702`
                                  where (`tps138`.`cash_account_log_201702`.`uid` = 1380238828)
                            union select sum(`tps138`.`cash_account_log_201703`.`amount`) AS `sum_amount`
                                  from `tps138`.`cash_account_log_201703`
                                  where (`tps138`.`cash_account_log_201703`.`uid` = 1380238828);

