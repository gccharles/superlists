create procedure pro_update_after_tickets()
  BEGIN
	#定义参数
	DECLARE t_id INT(11);
	DECLARE t_create_time VARCHAR(50);
  DECLARE t_ast_id INT(11);
	DECLARE t_sender INT(2);

	#定义循环变量
	DECLARE done INT DEFAULT 0;

	#游标赋值
	DECLARE cur_list CURSOR FOR (SELECT id, create_time FROM after_sale_tickets);

	#游标赋值
	DECLARE cur_list2 CURSOR FOR (SELECT ast_id,sender,create_time FROM (SELECT * FROM after_sale_tickets_reply ORDER BY create_time desc) as t  GROUP BY ast_id ORDER BY id desc);

	#空值设置为1
	DECLARE CONTINUE HANDLER FOR NOT FOUND set done=1;
	#打开游标
	OPEN cur_list;
		#开始循环
    WHILE done = 0 DO
			#参数赋值
			FETCH cur_list INTO t_id,t_create_time;
		
			#修改售后工单最后回复时间
			UPDATE after_sale_tickets SET last_reply_time = FROM_UNIXTIME(t_create_time) WHERE id = t_id;
		#结束循环
		END WHILE;

	#关闭游标
	CLOSE cur_list;#关闭游标
	
	SET done =0;
	#打开游标
	OPEN cur_list2;
		#开始循环
		WHILE done = 0 DO
			#参数赋值
			FETCH cur_list2 INTO t_ast_id,t_sender,t_create_time;
			
			#修改售后工单最后回复时间，回复方
			UPDATE after_sale_tickets SET last_reply = t_sender, last_reply_time = t_create_time WHERE id = t_ast_id;
		#结束循环
		END WHILE;

	#关闭游标
	CLOSE cur_list2;#关闭游标
	
END;

