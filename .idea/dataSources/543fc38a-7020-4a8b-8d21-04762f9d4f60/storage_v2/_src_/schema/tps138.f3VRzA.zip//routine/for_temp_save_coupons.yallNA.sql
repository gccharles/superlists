create procedure for_temp_save_coupons(IN p_uid int(10), IN p_oid char(19))
  BEGIN
################处理升级订单代品券######################

DECLARE li_coupons_value int(11);#列表中的代品券面值
DECLARE li_coupons_num int(11);#列表中的代品券数量
DECLARE i int;#循环次数

DECLARE done int default 0;#定义循环的结束符
DECLARE cur_list CURSOR FOR select coupons_value,coupons_num from temp_save_coupons where order_id=p_oid and user_id=
p_uid;#取出信息列表（游标）
DECLARE CONTINUE HANDLER FOR NOT FOUND set done=1;#定义循环hander

#-----------循环开始-------------
OPEN cur_list;
FETCH cur_list INTO li_coupons_value,li_coupons_num;
WHILE done=0 do

	set i=0;
	while (i<li_coupons_num) do

		insert into user_suite_exchange_coupon(face_value,uid) values(li_coupons_value,p_uid);
		set i=i+1;
	end WHILE;

	FETCH cur_list INTO li_coupons_value,li_coupons_num;
END WHILE;
CLOSE cur_list;#关闭游标
#------------循环结束--------------

#清掉临时代品券表中的数据
delete from temp_save_coupons where user_id=p_uid and order_id=p_oid;

END;

