create procedure add_trade_orders_170612(IN customer_id int, IN area char(3), IN order_from tinyint)
  BEGIN
SET @id = 0;
SET @customer_id = customer_id;
SET @area = area;
SET @order_from = order_from;
SELECT IFNULL(MAX(id)+1,1) INTO @id FROM trade_orders_1706;
INSERT INTO trade_orders_1706(id,customer_id,area,order_from)
VALUES(@id,@customer_id,@area,@order_from);
COMMIT;
END;

