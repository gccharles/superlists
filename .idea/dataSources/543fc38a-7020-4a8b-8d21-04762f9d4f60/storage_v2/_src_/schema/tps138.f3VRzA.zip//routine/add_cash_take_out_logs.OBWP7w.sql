create procedure add_cash_take_out_logs(IN uid int(10), IN amount decimal(14, 2), IN status tinyint(1))
  BEGIN
SET @id = 0;
SET @uid = uid;
SET @amount = amount;
SET @status = status;
SET @create_time = STR_TO_DATE('" + alarmDefi.getEndTime()+ "','%Y-%m-%d %k:%i:%s');

SELECT IFNULL(MAX(id)+1,1) INTO @id FROM cash_take_out_logs;
INSERT INTO cash_take_out_logs(id,uid,amount,status,create_time)
VALUES(@id,@uid,@amount,@status,@create_time);
COMMIT;
END;

