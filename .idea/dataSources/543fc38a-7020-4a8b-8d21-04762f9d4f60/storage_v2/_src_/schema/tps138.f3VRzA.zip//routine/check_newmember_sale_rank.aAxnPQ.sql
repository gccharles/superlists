create procedure check_newmember_sale_rank(IN p_uid int(10))
  BEGIN
################核算新升级会员的自身职称######################
#参数说明
#p_uid 新升级的会员id

DECLARE g_vp_num int(10);#有市场总监的分支数
DECLARE g_sd_num int(10);#有高级市场主管的分支数
DECLARE g_sm_num int(10);#有市场主管的分支数
DECLARE g_mso_num int(10);#有资深店主的分支数
DECLARE g_payed_child_num int(10);#直推的付费店铺数

###检查自己的职称
select count(*) into g_vp_num from users_child_group_info where uid=p_uid and vp_num>0;
if g_vp_num>2 THEN

	update users set sale_rank=5,sale_rank_up_time=now() where id=p_uid;
ELSE

	select count(*) into g_sd_num from users_child_group_info where uid=p_uid and sd_num>0;
	if g_sd_num>2 THEN

		update users set sale_rank=4,sale_rank_up_time=now() where id=p_uid;
	ELSE
		
		select count(*) into g_sm_num from users_child_group_info where uid=p_uid and sm_num>0;
		if g_sm_num>2 THEN

			update users set sale_rank=3,sale_rank_up_time=now() where id=p_uid;
		ELSE

			select count(*) into g_mso_num from users_child_group_info where uid=p_uid and mso_num>0;
			if g_mso_num>2 THEN
				
				update users set sale_rank=2,sale_rank_up_time=now() where id=p_uid;
			ELSE
				
				select count(*) into g_payed_child_num from users where parent_id=p_uid and user_rank<>4;
				if g_payed_child_num>2 THEN

					update users set sale_rank=1,sale_rank_up_time=now() where id=p_uid;
				end if;
			end if;
		end if;
	end if;
end if;

END;

