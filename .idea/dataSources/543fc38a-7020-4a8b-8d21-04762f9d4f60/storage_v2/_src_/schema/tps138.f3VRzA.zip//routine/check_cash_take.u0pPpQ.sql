create procedure check_cash_take()
  BEGIN
/* 声明变量 */
DECLARE Done INT DEFAULT 0;
/* 用户id */
DECLARE CurrentUid INT(10);
/* 取消总笔数 */	   
declare CancleNum INT(10);
/* 返回总笔数 */	   
declare Type12Num INT(10);
/* 重复取消次数 */
declare errNum INT(10);
/* 声明游标 */

DECLARE rs CURSOR FOR SELECT COUNT(*) as num,uid from cash_take_out_logs where `status`=4 GROUP BY uid;

/* 异常处理 */
DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET Done = 1;

/* 打开游标 */
OPEN rs;
/* 逐个取出当前记录uid字段的值，需要进行取消提现次数与返回笔数对比 */
FETCH NEXT FROM rs INTO CancleNum, CurrentUid; 
/* 遍历数据表 */
REPEAT
  IF NOT Done THEN
  SELECT   (
				SELECT
					COUNT(*)
				FROM
					commission_logs
				WHERE
					uid = CurrentUid
				AND type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201607
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201608
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201609
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201610
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201611
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201612
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201701
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201702
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201703
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201704
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201705
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201706
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201707
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201708_1380
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201708_1381
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201708_1382
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201708_1383
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201708_1384
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201708_1385
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201708_1386
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201708_1387
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1380
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) + (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1381
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1382
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1383
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1384
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1385
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1386
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1387
				WHERE
					uid = CurrentUid
				AND item_type = 12
			)+ (
				SELECT
					COUNT(*)
				FROM
					cash_account_log_201709_1388
				WHERE
					uid = CurrentUid
				AND item_type = 12
			) into Type12Num;
			
  set errNum = Type12Num - CancleNum;
  
  IF errNum  > 0 THEN 
   INSERT INTO cash_take_cancle_err_log(`uid`,`Num`)VALUES(CurrentUid,errNum);
set errNum=0;
set Type12Num=0;
set CancleNum=0;
	END IF;
 END IF;

FETCH NEXT FROM rs INTO CancleNum, CurrentUid; 
 
UNTIL Done END REPEAT;

/* 关闭游标 */
CLOSE rs;
END;

