create procedure add_users(IN id int(10), IN amount decimal(14, 2), IN profit_sharing_point decimal(14, 2))
  BEGIN
SET @id = id ;
SET @amount = amount;
SET @profit_sharing_point = profit_sharing_point;
SET @update_time = unix_timestamp(now());

INSERT INTO users (id,amount,profit_sharing_point,update_time) 
VALUES(@id,@amount,@profit_sharing_point,@update_time);

UPDATE users u SET u.amount = @amount,u.profit_sharing_point = @profit_sharing_point,u.update_time = @update_time WHERE  id = 136111;
UPDATE users u SET u.amount = @amount,u.profit_sharing_point = @profit_sharing_point,u.update_time = @update_time WHERE  id = 136112;
UPDATE users u SET u.amount = @amount,u.profit_sharing_point = @profit_sharing_point,u.update_time = @update_time WHERE  id = 136113;
UPDATE users u SET u.amount = @amount,u.profit_sharing_point = @profit_sharing_point,u.update_time = @update_time WHERE  id = 136114;

COMMIT;
END;

