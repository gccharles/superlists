create procedure add_cash_account_log_201710_1380(IN uid int, IN item_type tinyint, IN amount int)
  BEGIN
SET  @uid = uid;
SET  @item_type = item_type;
SET  @amount = amount;
SET  @create_time = STR_TO_DATE('" + alarmDefi.getEndTime()+ "','%Y-%m-%d %k:%i:%s');
SET  @id = 0;

SELECT IFNULL(MAX(id)+1,1) INTO @id FROM cash_account_log_201710_1380;
INSERT INTO cash_account_log_201710_1380(id,uid,item_type,amount,create_time)
VALUES(@id,@uid,@item_type,@amount,@create_time);
COMMIT;
END;

