create procedure add_trade_orders_17111(IN order_id char(19), IN customer_id int, IN order_prop tinyint,
                                        IN status   tinyint, IN order_amount_usd int, IN payment_type tinyint,
                                        IN area     char(3), IN order_from tinyint)
  BEGIN
SET @id = 0;
SET @order_id = order_id;
SET @customer_id = customer_id;
SET @order_prop = order_prop;
SET @status = status;
SET @pay_time = STR_TO_DATE('" + alarmDefi.getEndTime()+ "','%Y-%m-%d %k:%i:%s');
set @order_amount_usd= order_amount_usd;
SET @payment_type = payment_type;
SET @area = area;
set @order_from = order_from;
SET @updated_at = STR_TO_DATE('" + alarmDefi.getEndTime()+ "','%Y-%m-%d %k:%i:%s');

select ifnull(max(id)+1,1) into @id from trade_orders_1711;

INSERT INTO trade_orders_1711(id,order_id,customer_id,order_prop,status,pay_time,order_amount_usd,payment_type,area ,order_from,updated_at)
VALUES(@id,@order_id,@customer_id,@order_prop,@status,@pay_time,@order_amount_usd,@payment_type,@area,@order_from,@updated_at);
COMMIT;
END;

