create procedure give_monthlyfee_coupon(IN p_uid int(10), IN p_coupon_num int)
  BEGIN
################送月费券######################
#参数说明
#p_coupon_num 月费券的数量

DECLARE old_coupon_num int(10) DEFAULT 0;#旧的月费券数量
DECLARE new_coupon_num int(10) DEFAULT 0;#新月费券数量
DECLARE i int(10) DEFAULT 0;#用来控制循环遍历的次数
DECLARE u_month_fee_pool decimal(14,2);#用户月费池金额

SELECT count(*) into old_coupon_num from monthly_fee_coupon where uid=p_uid;

WHILE (i<p_coupon_num) do
	
	insert into monthly_fee_coupon(uid) values(p_uid);
	set i=i+1;
END WHILE;

SELECT count(*) into new_coupon_num from monthly_fee_coupon where uid=p_uid;
select month_fee_pool into u_month_fee_pool from users where id=p_uid;

insert into month_fee_change(user_id,old_month_fee_pool,month_fee_pool,cash,create_time,type,old_coupon_num,coupon_num,
coupon_num_change) values(p_uid,u_month_fee_pool,u_month_fee_pool,0,now(),3,old_coupon_num,new_coupon_num,p_coupon_num);

END;

